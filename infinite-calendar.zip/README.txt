A Pen created at CodePen.io. You can find this one at http://codepen.io/tadaima/pen/WGRXyA.

 A liquid & 'light-weight' calendar. There's no libraries in this exercise, it's really hand-crafted.

Check out our 'body-cut' effect :D

Hope enjoy!